# 						概述

### 一、Kubernetes (K8S) 是什么

[官网地址](https://kubernetes.io/zh/docs/concepts/overview/what-is-kubernetes/)

它是一个为 **容器化** 应用提供集群部署和管理的开源工具，由 Google 开发，在2014 年开源了 Kubernetes 项目。
**Kubernetes** 这个名字源于希腊语，意为“舵手”或“飞行员”。k8s 这个缩写是因为 k 和 s 之间有八个字符。 



#### 不同的应用部署方案

![container_evolution.svg](https://sjwx.easydoc.xyz/46901064/files/kwmxgxwp.svg)

##### 传统部署方式：

应用直接在物理机上部署，机器资源分配不好控制，出现Bug时，可能机器的大部分资源被某个应用占用，导致其他应用无法正常运行，无法做到应用隔离。

##### 虚拟机部署

在单个物理机上运行多个虚拟机，每个虚拟机都是完整独立的系统，性能损耗大。

##### 容器部署

所有容器共享主机的系统，轻量级的虚拟机，性能损耗小，资源隔离，CPU和内存可按需分配



### 二、为什么需要Kubernetes,它能做什么?

Kubernetes 为你提供：

- **服务发现和负载均衡**

- **存储编排**

- **自动部署和回滚**

- **自动完成装箱计算**

- **自我修复**
- **密钥与配置管理**



### 三、Kubernetes 组件

#### Kubernetes 集群架构

![](./assets/components.png)

Kubernetes 主要由以下几个核心组件组成：

- etcd 保存了整个集群的状态；
- kube-apiserver 提供了资源操作的唯一入口，并提供认证、授权、访问控制、API 注册和发现等机制；
- kube-controller-manager 负责维护集群的状态，比如故障检测、自动扩展、滚动更新等；
- kube-scheduler 负责资源的调度，按照预定的调度策略将 Pod 调度到相应的机器上；
- kubelet 负责维持容器的生命周期，同时也负责 Volume（CVI）和网络（CNI）的管理；
- Container runtime 负责镜像管理以及 Pod 和容器的真正运行（CRI），默认的容器运行时为 Docker；
- kube-proxy 负责为 Service 提供 cluster 内部的服务发现和负载均衡；

除了核心组件，还有一些推荐的 Add-ons：

- kube-dns 负责为整个集群提供 DNS 服务
- Ingress Controller 为服务提供外网入口
- Dashboard 提供 GUI
- ...



### 四、Kubernetes 对象

[理解 Kubernetes 对象](https://kubernetes.io/zh-cn/docs/concepts/overview/working-with-objects/kubernetes-objects/)

> k8s对象都有3大类属性：元数据metadata、规范spec和状态status
>
> 元数据：标识API对象
>
> spec： 对象期望状态
>
> status：对象当前状态
>
> 在任何时刻，Kubernetes **控制平面**都一直都在积极地管理着对象的实际状态，以使之达成期望状态

- **Namespace**

Namespace 将同一集群中的资源划分为相互隔离的组，提供虚拟的隔离作用。

- **Node**
- **Pod**
- **Deployment**
- **Service**
- **StatefulSet**
- **DaemonSet**
- **Job**
- **Volume**
- **ComfigMap**
- **Secret**
- **Ingress**



### 五、工作负载分类

- Deployment
  适合无状态应用，所有pod等价，可替代
- StatefulSet
  有状态的应用，适合数据库这种类型。
- DaemonSet
  在每个节点上跑一个 Pod，可以用来做节点监控、节点日志收集等
- Job & CronJob
  Job 用来表达的是一次性的任务，而 CronJob 会根据其时间规划反复运行。
